﻿using System;
using System.Collections.Generic;

namespace GCUBankModel
{
    public class Account
    {
        protected decimal startingBalance;
 
        private string accountNumber;

        public string AccountNumber
        {
            get { return accountNumber; }
            set { accountNumber = value; }
        }

        protected Dictionary<String,ITransaction> transactions;

        public Account(string accountNumber, decimal startingBalance)
        {
            this.accountNumber = accountNumber;
            this.startingBalance = startingBalance;
            transactions = new Dictionary<String,ITransaction>();
        }

        public void AddTransaction(ITransaction transaction)
        {
            //TODO: implement code which adds the transaction object to the transactions collection
        }

        public ICollection<ITransaction> GetTransactions()
        {
            return transactions.Values;
        }

        public ITransaction GetTransaction(string transactionID)
        {
            return transactions[transactionID];
        }

        public decimal GetBalance()    //TODO: modify the method declaration so that it can be overridden by a derived class
        {
            //TODO: implement code which calculates the balance by adding up the
            //amounts of all transactions and adding to the starting balance
            return 0m;
        }

        public void CancelTransaction(string transactionID)
        {
            //TODO: implement code which cancels the transaction
            //with the given transactionID - if there is no transaction
            //with that transactionID no action should be taken, but you
            //should make sure that no exception is thrown in that case
        }
           
    }
}
