﻿using System;
using System.Collections.Generic;

namespace GCUBankModel
{
    public class SavingsAccount : Account
    {
        private decimal interestRate;

        public decimal InterestRate
        {
            get { return interestRate; }
            set { interestRate = value; }
        }

        private decimal accruedInterest;

        public SavingsAccount(string accountNumber, decimal startingBalance, decimal interestRate) :
            base(accountNumber, startingBalance)
        {
            this.interestRate = interestRate;
        }

        public decimal GetBalance()   //TODO: modify the method declaration so that it overrides the base class method
        {
            //TODO: implement code which calculates the balance by adding up the
            //amounts of all transactions and the accrued interest and adding these to the starting balance 
            return 0m;
        }

        public void AddInterest()
        {
            // TODO: implement code which calculates the interest on the current balance
            // and adds it to accruedInterest. The interestRate value is the percentage interest rate, so the
            // interest to be added is an amount based on the current balance and that percentage
        }
    }
}
