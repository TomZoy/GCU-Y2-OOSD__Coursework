﻿
Partial Class EditPeople
    Inherits System.Web.UI.Page

End Class
