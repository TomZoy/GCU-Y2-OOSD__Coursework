﻿
Partial Class LookUpPeople
    Inherits System.Web.UI.Page

End Class
