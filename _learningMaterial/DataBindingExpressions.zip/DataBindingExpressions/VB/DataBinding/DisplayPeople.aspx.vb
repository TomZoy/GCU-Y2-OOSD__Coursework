﻿
Partial Class DisplayPeople
    Inherits System.Web.UI.Page

End Class
