﻿
namespace HealthCentreSystem
{
    public interface IPerson
    {
        string ID { get; set; }

        string GetFullName(); 
    }
}
